# EDUCON — Student Application OS

A full-stack starter for the EDUCON education consultancy management platform.
This implementation begins with a real end-to-end vertical slice: Supabase authentication,
protected application shell, student registration, persistent student records, search, and
a responsive student directory. It is designed to be extended page-by-page.

## Stack
- Next.js App Router + TypeScript
- Tailwind CSS
- Supabase Auth + PostgreSQL + private Storage
- Server-side Supabase client and Row Level Security (RLS)

## Important status
This is source code, not a deployed production service. A working public deployment requires
your own Supabase project and hosting account credentials. Do not put real student records into
a public demo until authentication, RLS, storage policies, and organization membership have
been reviewed and tested.

## 1. Requirements
- Node.js 20+
- A Supabase project
- A Vercel account (or another compatible Node.js host)
- Git

## 2. Configure Supabase
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/migrations/0001_initial.sql`.
3. In Authentication > URL Configuration, set the Site URL to your local app URL while
   developing (`http://localhost:3000`). Add the deployed URL later.
4. In Authentication > Providers, enable Email. For initial testing, create a user in
   Authentication > Users (or enable sign-up and use the app's sign-in page).
5. Create a private Storage bucket named `student-documents`. Storage policies are intentionally
   not included as a permissive default; add policies after choosing your organization-membership
   model. Do not make the bucket public.

## 3. Run locally
```bash
npm install
cp .env.example .env.local
# Fill in the two Supabase public values from Project Settings > API
npm run dev
```
Open `http://localhost:3000`.

## 4. Environment variables
- `NEXT_PUBLIC_SUPABASE_URL`: Supabase project URL
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Supabase publishable/anon key. This is safe for browser use
  only when RLS is correctly enabled. Never put a service-role key in a `NEXT_PUBLIC_` variable.

## 5. Deploy
1. Push this folder to a private GitHub repository.
2. Import the repository into Vercel.
3. Add the two environment variables above in Vercel project settings.
4. Deploy, then update Supabase Auth Site URL and redirect URLs to the real domain.
5. Smoke-test sign-in, create/edit/search, refresh persistence, and unauthorized access.
6. Before production use, implement organization membership and roles, secure document upload/download
   policies, audit events, backups, import/export, and automated tests.

## Current vertical slice
- Sign-in via Supabase Auth
- Protected workspace
- Student creation and editing
- Student search
- Persistent PostgreSQL records
- Student ID generation
- Basic input validation and responsive UI
- Database RLS policies for authenticated users in a single-team initial setup

## Planned next slices
1. Organization memberships and admin/counselor/read-only RBAC
2. Student profile tabs, documents and application tracking
3. University/course directory and deadline calendar
4. Offers/outcomes
5. Historical repository, CSV import/export, audit history
6. Automated tests, production hardening and deployment verification
