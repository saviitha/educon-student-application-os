import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

function clean(v: unknown) { return typeof v === 'string' ? v.trim() : ''; }
export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  let body: Record<string, unknown>;
  try { body = await request.json(); } catch { return NextResponse.json({error:'Invalid JSON body'}, {status:400}); }
  const full_name = clean(body.full_name);
  const email = clean(body.email).toLowerCase() || null;
  const mobile = clean(body.mobile) || null;
  if (full_name.length < 2 || full_name.length > 160) return NextResponse.json({error:'Enter a name between 2 and 160 characters.'},{status:400});
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({error:'Enter a valid email address.'},{status:400});
  const payload = {
    full_name, email, mobile,
    degree: clean(body.degree) || null, branch: clean(body.branch) || null,
    college: clean(body.college) || null, graduation_year: body.graduation_year ? Number(body.graduation_year) : null,
    cgpa: body.cgpa !== '' && body.cgpa != null ? Number(body.cgpa) : null,
    aps_status: clean(body.aps_status) || 'Not Started',
    ielts_status: clean(body.ielts_status) || 'Not Started',
    ielts_score: body.ielts_score !== '' && body.ielts_score != null ? Number(body.ielts_score) : null,
    gre_score: body.gre_score !== '' && body.gre_score != null ? Number(body.gre_score) : null,
    intake: clean(body.intake) || 'Winter', intake_year: body.intake_year ? Number(body.intake_year) : new Date().getFullYear(),
    country_preference: clean(body.country_preference) || 'Germany',
    course_preference: clean(body.course_preference) || null,
    stage: clean(body.stage) || 'Registered', priority: clean(body.priority) || 'Medium',
    internal_notes: clean(body.internal_notes) || null,
    next_follow_up: clean(body.next_follow_up) || null,
    created_by: user.id, updated_by: user.id
  };
  if (payload.cgpa !== null && (!Number.isFinite(payload.cgpa) || payload.cgpa < 0 || payload.cgpa > 100)) return NextResponse.json({error:'CGPA/percentage must be between 0 and 100.'},{status:400});
  if (payload.ielts_score !== null && (!Number.isFinite(payload.ielts_score) || payload.ielts_score < 0 || payload.ielts_score > 9)) return NextResponse.json({error:'IELTS score must be between 0 and 9.'},{status:400});
  if (payload.gre_score !== null && (!Number.isFinite(payload.gre_score) || payload.gre_score < 0 || payload.gre_score > 340)) return NextResponse.json({error:'GRE score must be between 0 and 340.'},{status:400});
  const { data, error } = await supabase.from('students').insert(payload).select('*').single();
  if (error) {
    if (error.code === '23505') return NextResponse.json({error:'A student with this email or mobile already exists.'},{status:409});
    return NextResponse.json({error:'Unable to save student. Check database configuration and try again.'},{status:500});
  }
  return NextResponse.json({student:data}, {status:201});
}
