import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'EDUCON — Student Application OS',
  description: 'Every student. Every application. Every deadline. One intelligent workspace.'
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body>{children}</body></html>;
}
