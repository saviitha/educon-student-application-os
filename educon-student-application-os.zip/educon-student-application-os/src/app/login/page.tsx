'use client';
import { FormEvent, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { GraduationCap, ArrowRight } from 'lucide-react';

export default function LoginPage() {
  const [email,setEmail] = useState(''); const [password,setPassword] = useState('');
  const [busy,setBusy] = useState(false); const [error,setError] = useState('');
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError('');
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({email,password});
    if (error) { setError(error.message); setBusy(false); return; }
    window.location.href = '/';
  }
  return <main className="min-h-screen grid lg:grid-cols-2 bg-white">
    <section className="hidden lg:flex flex-col justify-between p-12 text-white" style={{background:'radial-gradient(circle at 80% 10%,#923EFF,transparent 36%),linear-gradient(145deg,#28104F,#7628F5)'}}>
      <div className="flex items-center gap-3"><span className="rounded-xl bg-white/15 p-3"><GraduationCap/></span><span className="text-2xl font-bold tracking-tight">EDUCON</span></div>
      <div><p className="text-sm uppercase tracking-[.24em] text-purple-200">Student Application OS</p><h1 className="mt-5 max-w-xl text-5xl font-semibold leading-tight">Every student. Every application. Every deadline.</h1><p className="mt-5 max-w-lg text-lg text-purple-100">One intelligent workspace for your admissions team.</p></div>
      <p className="text-sm text-purple-200">A focused workspace for better student journeys.</p>
    </section>
    <section className="flex items-center justify-center p-6 sm:p-12">
      <form onSubmit={submit} className="w-full max-w-md">
        <div className="mb-8 flex items-center gap-3 lg:hidden"><span className="rounded-xl bg-purple-100 p-3 text-purple-700"><GraduationCap/></span><span className="text-2xl font-bold">EDUCON</span></div>
        <p className="text-sm font-semibold uppercase tracking-widest text-purple-700">Welcome back</p><h2 className="mt-2 text-3xl font-bold">Sign in to your workspace</h2><p className="mt-3 text-sm text-gray-500">Use the team account created in your Supabase project.</p>
        <label className="mt-8 block text-sm font-semibold">Email address<input className="field mt-2" type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.com"/></label>
        <label className="mt-5 block text-sm font-semibold">Password<input className="field mt-2" type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter your password"/></label>
        {error && <p role="alert" className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
        <button className="btn-primary mt-6 flex w-full items-center justify-center gap-2" disabled={busy}>{busy?'Signing in…':'Sign in'} <ArrowRight size={17}/></button>
        <p className="mt-5 text-xs leading-5 text-gray-500">For security, account creation is managed by your administrator. If you need access, contact your system admin.</p>
      </form>
    </section>
  </main>;
}
