import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import Workspace from '@/components/workspace';

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { data: students, error } = await supabase.from('students')
    .select('*').is('archived_at', null).order('created_at', { ascending: false }).limit(100);
  return <Workspace initialStudents={students ?? []} userEmail={user.email ?? ''} loadError={error?.message ?? ''} />;
}
