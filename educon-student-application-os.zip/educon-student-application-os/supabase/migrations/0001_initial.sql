-- EDUCON initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  student_code text unique,
  full_name text not null check (char_length(full_name) between 2 and 160),
  date_of_birth date,
  email text,
  mobile text,
  alternate_contact text,
  city text,
  degree text,
  branch text,
  college text,
  graduation_year integer,
  cgpa numeric(5,2),
  grading_scale text,
  backlogs integer,
  aps_status text not null default 'Not Started',
  gre_status text,
  gre_score numeric(6,2),
  ielts_status text not null default 'Not Started',
  ielts_score numeric(3,1),
  toefl_score numeric(5,2),
  additional_exam_name text,
  additional_exam_score text,
  passport_status text,
  german_level text,
  intake text not null default 'Winter' check (intake in ('Winter','Summer')),
  intake_year integer not null default extract(year from now())::integer,
  country_preference text not null default 'Germany',
  course_preference text,
  assigned_counselor uuid references auth.users(id) on delete set null,
  stage text not null default 'Registered',
  priority text not null default 'Medium' check (priority in ('High','Medium','Low')),
  internal_notes text,
  next_follow_up date,
  created_by uuid references auth.users(id) on delete set null,
  updated_by uuid references auth.users(id) on delete set null,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create sequence if not exists public.student_code_seq start 1001;
create or replace function public.assign_student_code()
returns trigger language plpgsql as $$
begin
  if new.student_code is null or new.student_code = '' then
    new.student_code := 'EDU-' || to_char(now(), 'YY') || '-' || lpad(nextval('public.student_code_seq')::text, 5, '0');
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists students_assign_code on public.students;
create trigger students_assign_code before insert or update on public.students
for each row execute function public.assign_student_code();

create unique index if not exists students_email_unique_lower on public.students (lower(email)) where email is not null and email <> '';
create unique index if not exists students_mobile_unique on public.students (mobile) where mobile is not null and mobile <> '';
create index if not exists students_active_intake_idx on public.students (intake_year desc, intake) where archived_at is null;
create index if not exists students_stage_idx on public.students (stage);
create index if not exists students_created_at_idx on public.students (created_at desc);
create index if not exists students_name_search_idx on public.students using gin (to_tsvector('simple', full_name));

alter table public.students enable row level security;
drop policy if exists "authenticated team can read students" on public.students;
create policy "authenticated team can read students" on public.students for select to authenticated using (true);
drop policy if exists "authenticated team can insert students" on public.students;
create policy "authenticated team can insert students" on public.students for insert to authenticated with check (true);
drop policy if exists "authenticated team can update students" on public.students;
create policy "authenticated team can update students" on public.students for update to authenticated using (true) with check (true);

-- NOTE: There is intentionally no DELETE policy. Archive records instead.
-- This initial RLS model assumes all authenticated users belong to one trusted team.
-- Before inviting multiple organizations or read-only users, replace it with membership/role policies.

create table if not exists public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  entity_type text not null,
  entity_id uuid,
  action text not null,
  summary text,
  created_at timestamptz not null default now()
);
alter table public.activity_logs enable row level security;
create policy "authenticated team can read activity logs" on public.activity_logs for select to authenticated using (true);
-- Write audit logs from trusted server-side functions after role and actor validation.
